/*globals ArrayList arr*/
/*eslint-env node */
var ical = require('ical');
//var arraytob= require('arrays-to-object');
var ArrayList = require('arraylist');
var sortarray = require('sort-array');
           var arr = new ArrayList();
            var list = new ArrayList();
 console.log("mozhi is ere"); 
    ical.fromURL('https://calendar.google.com/calendar/ical/o8mfhn5drq7t875vosh3b5kdao%40group.calendar.google.com/public/basic.ics', {}, function(err, data) {
      if (err)
      {
                  console.log("error nowthea");
      }
      else{
      for (var k in data){
        if (data.hasOwnProperty(k)) {
            var ev = data[k];   
 
              arr=[{'summary':ev.summary,'start':ev.start,'end':ev.end}];
               //console.log("get the row",ev.summary,ev.start,ev.end) -- fetching correct output thou it has duplicates
               list.add(arr);     
               
               // ArrayList is not working
             console.log("ArrayList_nowthea",list);
         
        }
        
      }
                                
                       /* arraytob(list);
                      console.log("theanmozhi arraytob",arraytob);*/
  }

    });